#include <iostream>
using namespace std;

struct node {
	int data;
	node* left = NULL, * right = NULL;
};

void print(node* p) {
	if (p) {
		print(p->left);
		cout << p->data << " ";
		print(p->right);
	}
}

int sum_lens_way(node* p, int L) {
	int s;
	if (!p) s = 0;
	else
	{
		s = L + sum_lens_way(p->left, L + 1) + sum_lens_way(p->right, L + 1);
	}
	return s;
}
int check_size(node* p) {
	int size_tree;
	if (!p) size_tree = 0;
	else
	{
		size_tree = 1 + check_size(p->left) + check_size(p->right);
	}
	return size_tree;
}

int srendya_visota(node* p) {
	return(sum_lens_way(p, 1) / check_size(p));
}

int check_sum(node* p) {
	int sum;
	if (!p) sum = 0;
	else
	{
		sum = p->data + check_sum(p->left) + check_sum(p->right);
	}
	return sum;
}

int tree_height(node* p) {
	if (!p) return -1;
	return 1 + max(tree_height(p->left), tree_height(p->right));
}

int main()
{
	node* root = new node;;
	root->data = 5;
	root->left = new node;
	root->left->data = 1;
	root->left->left = new node;
	root->left->left->data = 3;
	root->left->right = new node;
	root->left->right->data = 2;
	root->left->left->left = new node;
	root->left->left->left->data = 6;
	root->left->left->right = new node;
	root->left->left->right->data = 7;

	cout << "\t\t\t" << root->data << endl;
	cout << "\t\t" << root->left->data << endl;
	cout << "\t" << root->left->left->data << "\t\t" << root->left->right->data  << endl;
	cout << " " << root->left->left->left->data << "\t\t" << root->left->left->right->data << endl;

	cout << "size: " << check_size(root) << " sum: " << check_sum(root) << " height: " << tree_height(root) << " mid_height: " << srendya_visota(root) << endl;
	print(root);
	return 0;
}
