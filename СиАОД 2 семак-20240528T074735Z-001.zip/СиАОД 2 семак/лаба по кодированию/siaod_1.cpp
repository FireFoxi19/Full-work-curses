#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <string.h>
#define max(a,b)  (((a) > (b)) ? (a) : (b))



int collisionsLP=0;
int collisionsQP=0;
int cLP_total=0;
int cQP_total=0;
int S1=0;int S2=0;

struct Tree
{
    int data;
    int Bal;
    struct Tree* left;
    struct Tree* right;
};

typedef struct stack
{
   struct stack* next;
   int data;
}st;


void Fillrand(int a[],int n)
{
	int i;
    //srand(time(NULL));
	for(i=0;i<n;i++)
		a[i]= rand()%100;	
}

void Fillinc(int a[],int n)
{
	int i;

	for(i=0;i<n;i++)
		a[i]= i;	
}

void Printmas(int a[],int n)
{
	printf("\n");
	int i;
	for(i=0;i<n;i++)
	{
		if(a[i]==-1 && (i+1)%15==0)
		printf("|_|\n");
		else if(a[i]==-1 && (i+1)%15!=0)
		printf("|_|\t");
		else if((i+1)%15==0)
		printf("|%d|\n",a[i]);
		else
		printf("|%d|\t",a[i] );
		
	}
}

void QuickSort(int a[], int L, int R)
{
	int x=a[L],i=L, j=R, m;
	while(i<=j)
	{
		while(a[i]<x)
		i++;
		while(a[j]>x)
		j--;
		if(i<=j)
		{
			m=a[i];
			a[i]=a[j];
			a[j]=m;
			i++;
			j--;
		}
	}
	if(L<j)
	QuickSort(a,L,j);
	if(i<R)
	QuickSort(a,i,R);
	
}	

st* Hash_Insert_DLmethod(int i, st* head){
	
   st *p=(st*)malloc(sizeof(st));
   p->data=i;
   p->next=head;
   //head->next=p;
   return p;
}

int Hash_Search_DLmethod(int find, st* head){
	st* p;
	int i;
	  	
    p=head;
  	
  	while(p!=NULL){ 
  		if(p->data==find) return i; 
  		i++;
  		p=p->next;          
	  }	
	return -1;
}

void Hash_Insert_OAmethod_LP(int H[],int k, int m)
{	
	collisionsLP=0;	
	int j,i=0;
	do{
		j=(k%m+i)%m;
		if(H[j]==-1)
		{		
			H[j]=k;
			break;
		}
		i++;
		collisionsLP++;
	}while(i<=m);
	cLP_total+=collisionsLP;
}

void Hash_Insert_OAmethod_QP(int H[],int k, int m)
{	
	collisionsQP=0;	
	int j,i=0;
	do{
		j=(k%m+i*i)%m;
		if(H[j]==-1)
		{		
			H[j]=k;
			break;
		}
		i++;
		collisionsQP++;
	}while(i<=m);
	cQP_total+=collisionsQP;
}

int check_IsPrimeNum(int m)
{
	int i;
	for(i=2;i<m;i++)
	{
		if(m%i==0 && m!=i)
		return 0;
	}
	return 1;
}

 void printlist(st* h)
{
	while(h!=NULL)
	{
		printf("%d ",h->data);
		h=h->next;
	}	
}

int TreeSize(Tree* p)
{
int n=0;
if(p!=NULL)
n=1+TreeSize(p->left)+TreeSize(p->right);

return n;
}

int C_Sum(Tree* p)
{
int s=0;
if(p!=NULL)
s=p->data+C_Sum(p->left)+C_Sum(p->right);
return s;
}

int TreeHeight(Tree* p)
{
int h=0;
if(p!=NULL)
h=1+max(TreeHeight(p->left),TreeHeight(p->right));
return h;
}

int Sum_Of_Paths(Tree* p, int L)
{
int s=0;
if(p!=NULL)
s=L+Sum_Of_Paths(p->left,L+1)+Sum_Of_Paths(p->right,L+1);
return s;
}

void INfix_PrintTree(Tree* Root)
{
	if(Root!=NULL)
{
		if(Root->left!=NULL)
	INfix_PrintTree(Root->left);
	printf("%d ", Root->data);
	if(Root->right!=NULL)
	INfix_PrintTree(Root->right);
}
	
}

Tree* ISDP(float L, float R, int a[])
{
	float m; Tree*p;
	if(L>R) return NULL;
	else {
		m=ceil((L+R)/2);
		p=(Tree*)malloc(sizeof(Tree));
		p->data=a[int(m)];
		p->left=ISDP(L,m-1,a);
		p->right=ISDP(m+1,R,a);
		return p;
	}
}

int find(Tree* p, int a)
{	
	if(p!=NULL){
		if(a==p->data)
			{
				printf("position= %d", p->data+1);
					return 1;
			}
		
		else if(a>p->data)
			find(p->right, a);
		else if(a<p->data)
			find(p->left,a);	
		}
	else return 0;
	
}

void add_to_SDP_r(int D,Tree* &p)
{
	if(p==NULL)
	{
			p=(Tree*)malloc(sizeof(Tree));
			p->data=D;
			p->left=p->right=NULL;			
	}
	else if(D < p->data)
			add_to_SDP_r(D, p->left);
	else if(D>= p->data)	
			add_to_SDP_r(D, p->right);
	else return;
}

void SDP_r(int a[], int N, Tree*& p )
{
	p=NULL;
	puts("");
	for(int i=0; i<N; i++)
		add_to_SDP_r(a[i],p);
	puts("\n");	
}

void add_to_SDP_di(int D, Tree** root)
{
	Tree*** p;
	p=&root;
	
	while(**p!=NULL)
	{
		if(D<(**p)->data)			
		    *p=&((**p)->left);
		else if(D>=(**p)->data)
			*p=&((**p)->right);	 
		else break;
	}
	if(**p==NULL)
	{
		**p=(Tree*)malloc(sizeof(Tree));
		(**p)->data=D;
		(**p)->left=(**p)->right=NULL;
	}
}

void SDP_di(int a[], int N, Tree** p )
{
	*p=NULL;
	puts("");
	for(int i=0; i<N; i++)
		add_to_SDP_di(a[i],p);
	puts("\n");	
}

void Del(int D,Tree** root)
{
	Tree**p=root;
	while(*p!=NULL)
	{
		if(D<(*p)->data)
			p=&((*p)->left);
		else if(D>(*p)->data)
			p=&((*p)->right);
		else break;	
	}
	if(*p!=NULL)
	{
		Tree* q=*p;
		if(q->left==NULL)
			*p=q->right;
		else if(q->right==NULL)
			*p=q->left;		
		else{
			Tree*r=q->left;
			Tree*s=q;
			if(r->right==NULL)
			{
				r->right=q->right;
				*p=r;
			}
			else
			{
				while(r->right!=NULL)
				{
					s=r;
					r=r->right;
				}
				s->right=r->left;
				r->left=q->left;
				r->right=q->right;
				*p=r;
			}
		}
		free(q);	
	}
}

void LL(Tree *&p){
	Tree *q;
	q=p->left;
	p->Bal=0;
	q->Bal=0;
	p->left=q->right;
	q->right=p;
	p=q;
}

void RR(Tree *&p){
	Tree *q;
	q=p->right;
	p->Bal=0;
	q->Bal=0;
	p->right=q->left;
	q->left=p;
	p=q;
}

void LR(Tree *&p){
	Tree *q,*r;
	q=p->left;
	r=q->right;
	
	if(r->Bal<0) p->Bal=1;
	else p->Bal=0;
	
	if(r->Bal>0) q->Bal=-1;
	else q->Bal=0;
	
	r->Bal=0;
	q->right=r->left;
	p->left=r->right;
	r->left=q;
	r->right=p;
	p=r;
}

void RL(Tree *&p){
	Tree *q,*r;
	q=p->right;
	r=q->left;
	
	if(r->Bal>0) p->Bal=-1;
	else p->Bal=0;
	
	if(r->Bal<0) q->Bal=1;
	else q->Bal=0;
	
	r->Bal=0;
	q->left=r->right;
	p->right=r->left;
	r->left=p;
	r->right=q;
	p=r;
}
int Rost;

void add_to_AVL(int D, Tree* &p)
{
	
	if(p==NULL)
	{
		p=(Tree*)malloc(sizeof(Tree));
		p->data=D;
		p->left=p->right=NULL;
		p->Bal=0;
		Rost=1;	
	}
	else if(p->data>D)
	{
		add_to_AVL(D,p->left);
		if(Rost==1){
			if(p->Bal>0)
			{
				p->Bal=0;
				Rost=0;
			}
			else if(p->Bal==0) 
			{
				p->Bal=-1;
				Rost=1;
			}
			else {
				if(p->left->Bal<0){ LL(p);Rost=0;}		
				else			  { LR(p),Rost=0;}	
			}
		}
	}
	else if(p->data<=D)
	{
		add_to_AVL(D,p->right);
		if(Rost==1){
			if(p->Bal<0){p->Bal=0;Rost=0;}
			else if(p->Bal==0) {p->Bal=1;Rost=1;}
			else {
				if(p->right->Bal>0){RR(p);Rost=0;}
				else				{RL(p);Rost=0;}
			}
		}
	}
		
}

void AVL(int a[], int N, Tree*& p )
{
	p=NULL;
	puts("");
	for(int i=0; i<N; i++)
		add_to_AVL(a[i],p);
	puts("\n");
}
int Umen; 

void LL1(Tree *&p){
	Tree *q;
	q=p->left;
	if(q->Bal==0){
		q->Bal=1;
		p->Bal=-1;
		Umen=false;
	}
	else{
		q->Bal=0;
		p->Bal=0;
}
	p->left=q->right;
	q->right=p;
	p=q;
}

void RR1(Tree *&p){
	Tree *q;
	q=p->right;
	if(q->Bal==0){
		p->Bal=1;
		q->Bal=-1;
		Umen=false;
	}
	else{
		q->Bal=0;
		p->Bal=0;
	}
	p->right=q->left;
	q->left=p;
	p=q;
}
void BL(Tree *&p){
	if(p->Bal==-1) p->Bal=0;
	else if(p->Bal==0){p->Bal=1; Umen=false;}
	else if(p->Bal==1){
		if(p->right->Bal>=0) RR1(p);
		else RL(p);
	}
}

void BR(Tree *&p){
	if(p->Bal==1) p->Bal=0;
	else if(p->Bal==0){p->Bal=-1; Umen=false;}
	else if(p->Bal==-1){
		if(p->left->Bal<=0) LL1(p);
		else LR(p);
	}
}

void DEL_avl(Tree *&r,Tree *&q){
	if(r->right!=NULL){ 
		DEL_avl(r->right,q);
		if(Umen==true) BR(r);
		}
	else{
		q->data=r->data;
		q=r;
		r=r->left;
		Umen=true;
	}
}

void DeleteAVL(Tree *&p,int x){
	Tree *q;
	if(p==NULL) {}
	else if(x<p->data){
		DeleteAVL(p->left,x);
		if(Umen==true) BL(p);
		}
	else if(x>p->data){
			DeleteAVL(p->right,x);
			if(Umen==true) BR(p);
		}
	else{
		q=p;
		if(q->left==NULL){p=q->right; Umen=true;}
		else if(q->right==NULL){p=q->left; Umen=true;}
		else{
			DEL_avl(q->left,q);
			if(Umen==true) BL(p);
			}
		delete q;
		}
}

struct sym{
	sym* next;
	float P;	
	char data;
	int num=0;
};

struct s1{
	float P;
	char data;
	int num;
  	float Q;  
 	int L;
  	char *C;
};

struct s2{
	float P;
	float Preal;
	char data;
	int num; 
 	int L=0;
  	char *C;
};


struct Queue {
	sym *head;
	sym *tail;
};

void LoadToList(sym*&head,char ch,int &size)
{
	if(head==NULL){
		head=new sym;
		head->data=ch;
		head->num++;
		size++;
		head->next=NULL;
		
	}	
	else if(head->data==ch)
		head->num++;
	else LoadToList(head->next, ch, size);
}

 void printinglist(sym* head,int size,int count, int a)
{
	while(head!=NULL)
	{	
		if(a==1){
		head->P=(float)head->num/count;
		}
	
		printf("\n%c\t%d\tp=%2.4f ",head->data, head->num,head->P);
		head=head->next;
	}	
}

void StackToQueue (struct sym**head, struct sym **tail) {
	(*tail)->next=*head;
	*tail=*head;
	*head=(*head)->next;
	(*tail)->next=NULL;
}

void MergeS (sym **head_a, sym **head_b, sym **tail, int q, int r) {
	while (q!=0 && r!=0) {
		
		if ((*head_a)->P<=(*head_b)->P) {
			StackToQueue (head_a, tail);	
			q--;
		}
		else {
			StackToQueue (head_b, tail);			
			r--;
		}
	}
	while (q>0) {
		StackToQueue (head_a, tail);		
		q--;
	}
	while (r>0) {
		StackToQueue (head_b, tail);	
		r--;
	}
}

void Split (sym **head, sym **head_a, sym **head_b) {
	sym *k, *p;
	*head_a=*head;
	*head_b=(*head)->next;
	k=*head_a;
	p=*head_b;	
	while (p!=NULL) {
		k->next=p->next;
		k=p;
		p=p->next;	
	}
}

void MergeSort (sym **head, sym **tail, int n) {
	int i, m, q, p=1, r;
	sym *a=NULL, *b=NULL;
	Queue c[2];
	Split (head, &a, &b);
	while (p<n) {
		c[0].tail=(sym*)&c[0].head;
		c[1].tail=(sym*)&c[1].head;
		i=0;
		m=n;
		while (m>0) {
			if (m>=p) q=p;
			else q=m;
			m-=q;
			if (m>=p) r=p;
			else r=m;
			m-=r;
			MergeS (&a, &b, &c[i].tail, q, r);
			i=1-i;
		}
		a=c[0].head;
		b=c[1].head;
		p*=2;
	}
	c[0].tail->next=NULL;
	*head=c[0].head;
}

sym* reversing(sym* head) 
{
	sym* new_head = NULL;
	while (head)
	{
		sym* next = head->next;
		head->next = new_head;
		new_head = head;
		head = next;
	}
	return new_head;
}

float totalP(s1 symbols[],float P,int size)
{
	int i=0;
	while(i<size)
	{	
		P+=symbols[i].P;		
		i++;
	}
	return P;	
}

void coding_Shennon(int &size,s1 charac[]){
	charac[0].Q=0;
  	charac[0].L=-log2(charac[0].P)+1;
  	for(int i=1;i<size;i++){
  		charac[i].Q=charac[i-1].Q+charac[i-1].P;
  		charac[i].L=-log2(charac[i].P)+1;
  	}  
  	for(int i=0;i<size;i++){
  		for(int j=0;j<charac[i].L;j++){
  			charac[i].Q=charac[i].Q*2;
  			if(charac[i].Q>=1){
  				 charac[i].C[j]='1';
  				 charac[i].Q-=1;
			  }
  			else charac[i].C[j]='0';	  		
  		}
	}
}

void coding_GilbertMur(int &size,s1 charac[]){
	charac[0].Q=0;
  	charac[0].L=-log2(charac[0].P)+2;
  	for(int i=1;i<size;i++){
  		charac[i].Q=charac[i-1].Q+(charac[i-1].P)/2;
  		charac[i].L=-log2(charac[i].P)+2;
  	}  
  	for(int i=0;i<size;i++){
  		for(int j=0;j<charac[i].L;j++){
  			charac[i].Q=charac[i].Q*2;
  			if(charac[i].Q>=1){
  				 charac[i].C[j]='1';
  				 charac[i].Q-=1;
			  }
  			else charac[i].C[j]='0';	  		
  		}
	}
}


int Med(s2 charac[],int L,int R)
{
	float S_l=0, S_r;int m;
	for(int i=L;i<R;i++)
		S_l+=charac[i].P;
	S_r=charac[R].P;
		m=R;
	while(S_l>=S_r)
	{
		m=m-1;
		S_l=S_l-charac[m].P;
		S_r=S_r+charac[m].P;
		}	
		return m;
}

void coding_Fano(s2 charac[], int L, int R, int k)
{
	int m;
	if(L<R)
	{
		k++;
		 m=Med(charac,L,R);
		for(int i=L; i<=R;i++)
		{
			if(i<=m) 
			{
				charac[i].C[k]='0';
				charac[i].L=charac[i].L+1;
			}
			else{
				charac[i].C[k]='1';
				charac[i].L=charac[i].L+1;
			}	
		}
		coding_Fano(charac, L,m,k);
		coding_Fano(charac, m+1,R,k);	
	}			
}

int Up(int n,float  q,s2 charac[])
{
	int j=0;
	for(int i=n-1;i>0;i--)
	{
		if(charac[i-1].P<=q)
			charac[i].P=charac[i-1].P;
		else 
			 {
			 	j=i;
			 	break;
			 }
	}
	charac[j].P=q;
	return j;	
}

void Down(int n,int j,s2 charac[],int size)
{
	char S[size];	
	for (int i = 0; i <size; i++)
		S[i] = charac[j].C[i];
//	strcpy(S,charac[j].C);
	int L=charac[j].L;
	for(int i=j;i<=n-2;i++)
	{
	//	strcpy(charac[i].C,charac[i+1].C);
	for (int k = 0; k < size; k++)
			charac[i].C[k] = charac[i + 1].C[k];
		charac[i].L=charac[i+1].L;
	}	
//	strcpy(charac[n-1].C,S);
//	strcpy(charac[n].C,S);
for (int i = 0; i < size; i++)
	{
		charac[n - 1].C[i] = S[i];
		charac[n].C[i] = S[i];
	}
	charac[n-1].C[L]='0';
	charac[n].C[L]='1';
	charac[n-1].L=L+1;
	charac[n].L=L+1;
}

void coding_Haffman(s2 charac[],int n,int size)
{
	if(n==1)
	{
		charac[0].C[0]='0';
		charac[0].L=1;
		charac[1].C[0]='1';
		charac[1].L=1;
	}
	else{
		float q=charac[n-1].P+charac[n].P;
		int j=Up(n,q,charac);
		coding_Haffman(charac,n-1,size);
		Down(n,j,charac,size);
	}
}

int main()
{
	int count=0,size=0;float Ptotal=0;
	float H=0,L_av1=0,L_av2=0,L_av3=0,L_av4=0,r=0;
	FILE *p=NULL;
	p=fopen("text.txt","r");
  	sym *head=NULL,	*tail=(sym*)&head;
  	char ch;
	if(p==NULL){
 		printf("Can't open file");
 		return 0;
 	}     
 	while ((ch=fgetc(p))!=EOF)                 
  	{    
  		if(ch!='\n' && ch!=' '){
  			count++;
			LoadToList(head,ch,size); 				
	  	}	
    }
  	fclose(p);
    puts("Char\tNum");
	printinglist(head,size,count,1);
	puts("\n");
		MergeSort(&head,&tail,size);
		head=reversing(head);
	s1 charac1[size];
	s2 charac2[size];
	s1 charac3[size];
	s2 charac4[size];
	printf("Size= %d",size);
	for(int i=0;i<size; i++)
	{	
		charac1[i].data=charac2[i].data=charac3[i].data=charac4[i].data=head->data;	
		charac1[i].num=charac2[i].num=charac3[i].num=charac4[i].num=head->num;
		charac1[i].P=charac2[i].P=charac3[i].P=charac4[i].P=charac4[i].Preal=head->P;
		charac1[i].C=new char[size];charac2[i].C=new char[size];charac3[i].C=new char[size];charac4[i].C=new char[size];		
		head=head->next;
	}
	puts("\nshennon\t\t\t\tfano\t\t\t\tgilbertmur\t\t\t\thaffman");
	coding_Shennon(size, charac1);	
	coding_Fano(charac2, 0,size-1,-1);
	coding_GilbertMur(size,charac3);
	coding_Haffman(charac4, size-1,size);	
	printf(" i  |Char|  P |  L | Code\ti  |Char|  P |  L | Code\ti  |Char|  P |  L | Code\ti  |Char|  P |  L | Code\n");
	for(int i=0;i<size;i++){
  		printf(" %3d| %c  |%.2f| %2d | ",i+1,charac1[i].data,charac1[i].P,charac1[i].L);
  		for(int j=0;j<charac1[i].L;j++) 
		  	printf("%c",charac1[i].C[j]);
  		printf("\t%3d| %c  |%.2f| %2d | ",i+1,charac2[i].data,charac2[i].P,charac2[i].L);
  		for(int j=0;j<charac2[i].L;j++) 
		  	printf("%c",charac2[i].C[j]);if(i==2)printf("\t");
  		printf("\t%3d| %c  |%.2f| %2d | ",i+1,charac3[i].data,charac3[i].P,charac3[i].L);
  		for(int j=0;j<charac3[i].L;j++) 
		  	printf("%c",charac3[i].C[j]);
		printf("\t%3d| %c  |%.2f| %2d | ",i+1,charac4[i].data,charac4[i].P,charac4[i].L);
  		for(int j=0;j<charac4[i].L;j++) 
		  	printf("%c",charac4[i].C[j]);
  		printf("\n");
	}
  	for(int i=0;i<size;i++){
  		H+=-charac1[i].P*log2f(charac1[i].P);
  		L_av1+=charac1[i].P*charac1[i].L;
  		L_av2+=charac2[i].P*charac2[i].L;
  		L_av3+=charac3[i].P*charac3[i].L;
	    L_av4+=charac4[i].Preal*charac4[i].L;	
  	}
 	printf("\n\nH: %.2f\nL_av_shennon: %.2f\nL_av_fano: %.2f\nL_av_gilbertmur: %.2f\n L_av_haffman: %.2f\nPtotal: %.2f\n",H,L_av1,L_av2,L_av3,L_av4,totalP(charac1,Ptotal,size));
    return 0;
}

