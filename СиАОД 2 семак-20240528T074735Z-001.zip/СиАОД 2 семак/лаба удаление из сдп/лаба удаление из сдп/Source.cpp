#include <iostream>
#include <cmath>
#include <sstream>
#include <iomanip>
using namespace std;
struct Vertex {
    int data;
    Vertex* left, * right;
};

void delete_vertex(int key, Vertex** root)
{
    Vertex** p = root;
    while (*p != NULL && (*p)->data != key)
    {
        if ((*p)->data < key) p = &((*p)->right);
        else if ((*p)->data > key) p = &((*p)->left);
    }

    if (*p != NULL) {
        Vertex* q = *p, * r = NULL, * s = NULL;
        if (q->left == NULL) *p = q->right;
        else if (q->right == NULL) *p = q->left;
        else
        {
            r = q->left;
            s = q;

            if (r->right == NULL) {
                r->right = q->right;
                *p = r;
            }
            else
            {
                while (r->right)
                {
                    s = r;
                    r = r->right;
                }


                s->right = r->left;
                r->left = q->left;
                r->right = q->right;
                *p = r;
            }
            delete q;
        }
    }
}

void obhod(Vertex* root) {
    if (root) {
        obhod(root->left);
        cout << root->data << setw(5);
        obhod(root->right);
    }
}
int treeSize(Vertex* root) {
    if (root) {
        return 1 + treeSize(root->left) + treeSize(root->right);
    }
    else {
        return 0;
    }
}
int treeHeight(Vertex* root) {
    if (!root) {
        return 0;
    }
    else {
        return 1 + max(treeHeight(root->left), treeHeight(root->right));
    }
}
int sum_way(Vertex* root, int hi = 0) {
    int sum = 0;
    if (root == NULL) return 0;
    else {
        sum = hi + sum_way(root->left, hi + 1) + sum_way(root->right, hi + 1);
    }
    return sum;
}
double treeMediumHeight(Vertex* root) {
    return (double)sum_way(root, 1) / treeSize(root);
}
int checkSum(Vertex* root) {
    if (root) {
        return root->data + checkSum(root->left) + checkSum(root->right);
    }
    else {
        return 0;
    }
}
void Delete(Vertex* root) {
    if (root) {
        Delete(root->right);
        Delete(root->left);
        delete root;
    }
}
void showInfo(Vertex* root) {
    cout << endl << "          Size: " << treeSize(root) << endl
        << "\n          Height: " << treeHeight(root) << endl
        << "\n          Medium height: " << treeMediumHeight(root) << endl
        << "\n          Check sum: " << checkSum(root) << endl
        << "\n          TreeLenSum = " << sum_way(root, 1) << endl
        << "\n          Obhod: ";
    obhod(root);
    cout << std::endl;
}

Vertex* SDP(const int array[], int l, int r) {
    if (l > r) {
        return 0;
    }
    else {
        int m = (l + r) / 2;
        Vertex* p = new Vertex;
        p->data = array[m];
        p->left = SDP(array, l, m - 1);
        p->right = SDP(array, m + 1, r);
        return p;
    }
}

void doublek(int data, Vertex*& p) {
    while (p != NULL)
    {
        if (data < p->data) p = p->left;
        else if (data > p->data) p = p->right;
        else
        {
            cout << "+";
        }

        if (!p)
        {
            p = new Vertex;
            p->data = data;
            p->left = NULL;
            p->right = NULL;
        }

    }
}
void rec(int data, Vertex*& p) {
    if (!p) {
        p = new Vertex;
        p->data = data;
        p->left = NULL;
        p->right = NULL;
    }
    else
    {
        if (data > p->data) rec(data, p->right);
        else if (data < p->data) rec(data, p->left);
        else {
            cout << "+";
        }
    }
}
void shekerSort(int* mas, int n)
{
    int last = n - 1, left = 1, right = n - 1, j;
    int s = 0, p = 0;
    do
    {
        for (j = right; j >= left; j--)
        {
            s++;
            if (mas[j - 1] > mas[j])
            {
                int buff = mas[j];
                p++;
                mas[j] = mas[j - 1];
                p++;
                mas[j - 1] = buff;
                p++;
                last = j;
            }
        }

        left = last + 1;

        for (j = left; j <= right; j++)
        {
            s++;
            if (mas[j - 1] > mas[j])
            {
                int buff = mas[j];
                p++;
                mas[j] = mas[j - 1];
                p++;
                mas[j - 1] = buff;
                p++;
                last = j;
            }
        }

        right = last - 1;

    } while (left < right);
    int g = s + p;
}


int main() {
    setlocale(LC_ALL, "Russian");
    int const size = 10;
    int arr[size];
    for (int i = 0; i < size; ++i) {
        arr[i] = rand() % 10 + 1;
    }
    shekerSort(arr, size);
    Vertex* tree_ispd = SDP(arr, 0, size - 1);
    showInfo(tree_ispd);
    int key;
    for (int i = 0; i < 10; i++)
    {
        cin >> key;
        delete_vertex(key, &tree_ispd);
        showInfo(tree_ispd);
        cout << endl;
    }
}