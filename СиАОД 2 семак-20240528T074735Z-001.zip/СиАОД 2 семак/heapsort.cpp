#include <iostream>
#include <iomanip>
#include <random>

using namespace std;

void FillInc(int n, int* a)
{
    for (int i = 1; i <= n; ++i)
    {
        a[i] = i;
    }
}

void FillDec(int n, int* a)
{
    for (int i = n; i >= 1; i--)
    {
        a[n - i] = i;
    }
}

void FillRand(int n, int* a)
{
    for (int i = 1; i <= n; ++i)
    {
        a[i] = rand() % n;

    }
}

void swap(int* fp, int* sp)
{
    int temp = *fp;
    *fp = *sp;
    *sp = temp;
}

void PrintMas(int n, int* a)
{
    for (int i = 1; i < n; ++i)
    {
        cout << a[i] << " ";
    }
}

void HeapForm(int* a, int l, int r, int& c, int& m)
{
    int x = a[l], j;
    int i = l;
    ++m;
    while (true)
    {
        j = 2 * i;
        ++c;
        if (j > r)
        {
            break;
        }
        ++c;
        if ((j < r) && (a[j + 1] <= a[j]))
            j = j + 1;
        ++c;
        if (x <= a[j])
        {
            break;
        }
        ++m;
        a[i] = a[j];
        i = j;
    }
    a[i] = x;
}

void HeapSort(int n, int* a, int& T)
{
    int l = n / 2, c = 0, m = 0;
    while (l > 0)
    {
        HeapForm(a, l, n, c, m);
        --l;
    }
    int r = n;
    while (r > 1)
    {
        m += 3;
        swap(a[1], a[r]);
        r--;
        HeapForm(a, 1, r, c, m);
    }
    T = c + m;

}

void PrintTabl()
{
    int n = 1, FR = 0, FD = 0, FI = 0;
    int* a = new int[n];
    cout << endl << "|               HeapSort                 |" << endl;
    cout << "| n |  FillInc  |  FillDec  |  FillRand  |" << endl;

    for (int n = 100; n <= 500; n += 100)
    {
        int T = 0;
        FillRand(n, a);
        HeapSort(n, a, T);
        FR = T;
        FillInc(n, a);
        HeapSort(n, a, T);
        FI = T;
        FillDec(n, a);
        HeapSort(n, a, T);
        FD = T;
        cout << "|" << n << "|" << setw(11) << FI << "|" << setw(11) << FD << "|" << setw(12) << FR << "|" << endl;
    }

    delete[] a;
}

int main()
{
    int T = 0;
    int n = 100;
    int* a;
    a = new int[n];
    FillRand(n, a);
    cout << "����������� ������" << endl;
    PrintMas(n, a);
    cout << endl;
    HeapSort(n, a, T);
    cout << "��������������� ������" <<  endl;
    PrintMas(n, a);
    PrintTabl();
}
