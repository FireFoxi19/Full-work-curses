#include "tree.h"
#include <algorithm>
#include <random>
#include <iomanip>
#include <iostream>

using namespace std;

void showInfo(const Tree& tree) {
    cout << "Size: " << tree.size()
        << "\nHeight: " << tree.height()
        << "\nMedium height: " << tree.mediumHeight()
        << "\nCheck sum: " << tree.checkSum()
        << "\nIn-order traversal (LNR): ";
    tree.printLNR();
}

void printTable(const Tree& a, const Tree& b, const Tree& c) {
    using std::setw;
    cout << "n = 100  Size  Check Sum  Height  Medium height\n"
        << "ISDP   "<<"|" << setw(6) << a.size() << "|" << setw(10) << a.checkSum() << "|" << setw(7) << a.height() << "|"
        << setw(14) << a.mediumHeight()<<"|" << '\n'
        << "SDP rec"<<"|" << setw(6) << b.size() << "|" << setw(10) << b.checkSum() << "|" << setw(7) << b.height() << "|"
        << setw(14) << b.mediumHeight()<<"|" << '\n'
        << "SDP dbl"<<"|" << setw(6) << c.size() << "|" << setw(10) << c.checkSum() << "|" << setw(7) << c.height() << "|"
        << setw(14) << c.mediumHeight()<<"|" << '\n';
}

int main() {
    const int n = 100;
    SdpTree recTree, doubleTree;
    /*int* arr = new int[n];*/
    int arr[n];
    for (int i = 0; i < n; i++) {
        arr[i] = i;
    }
    IsdpTree isdpTree(arr, n);
    auto rng = default_random_engine{};
    shuffle(&arr[0], &arr[n], rng);
    for (auto i : arr) {
        recTree.addRec(i);
        doubleTree.addDouble(i);
    }

    cout << "ISDP:\n";
    showInfo(isdpTree);
    cout << "\nRecoursive:\n";
    showInfo(recTree);
    cout << "\nDouble:\n";
    showInfo(doubleTree);

    cout << '\n';
    printTable(isdpTree, recTree, doubleTree);
}