#include <iostream>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <Windows.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
using namespace std;
int key;
struct record
{
	char author[12];
	char title[32];
	char publisher[16];
	short int year;
	short int num_of_page;

};



int strcomp(const string& str1, const string& str2, int len = -1) {
	if (len == -1) {
		len = (int)str1.length();
	}
	for (int i = 0; i < len; ++i) {
		if (str1[i] == '\0' and str2[i] == '\0') {
			return 0;
		}
		else if (str1[i] == ' ' and str2[i] != ' ') {
			return -1;
		}
		else if (str1[i] != ' ' and str2[i] == ' ') {
			return 1;
		}
		else if (str1[i] < str2[i]) {
			return -1;
		}
		else if (str1[i] > str2[i]) {
			return 1;
		}
	}
	return 0;
}
void scan(record* tt, record** B, int n)
{
	FILE* fp = NULL;
	fp = fopen("testBase1.dat", "rb");
	fread((record*)tt, sizeof(record), 4000, fp);
	fclose(fp);
	for (int i = 0; i < n; i++) // ������ � ������ ����������
	{
		B[i] = &tt[i];
	}

}
void print_database(record* tt, int n)
{
	int tmp;
	for (int i = 0; i < n; ++i)
	{
		cout << tt[i].author << setw(10) << "|" << tt[i].title << setw(8) << tt[i].publisher << setw(6) << tt[i].year << setw(10) << tt[i].num_of_page << endl;
		if (i % 20 == 0 && i != 0)
		{
			cout << "\nContinue? 0/1: " << endl;
			cin >> tmp;
			if (tmp == 1) system("CLS");
			if (tmp == 0) break;
		}
	}
}
void print_arr(record** B, int n)
{
	int tmp;
	for (int i = 0; i < n; ++i)
	{
		cout << B[i]->author << setw(10) << "|" << B[i]->title << setw(8) << B[i]->publisher << setw(6) << B[i]->year << setw(10) << B[i]->num_of_page << endl;
		if (i % 20 == 0 && i != 0)
		{
			cout << "\nContinue? 0/1: " << endl;
			cin >> tmp;
			if (tmp == 1) system("CLS");
			if (tmp == 0) break;
		}
	}
}

int strcomp(const char* str1, const char* str2)
{
	for (int i = 0; i < 12; ++i)
		if (str1[i] < str2[i]) return -1;
		else if (str1[i] > str2[i]) return 1;
	return 0;
}

int compare(const record& record1, const record& record2) {
	for (int i = 0; i < 16; ++i) {
		if (record1.publisher[i] < record2.publisher[i]) return -1;
		else if (record1.publisher[i] > record2.publisher[i]) return 1;
	}
	return strcomp(record1.author, record2.author);
}


void Heap(struct record** B, int L, int R)
{
	int i(L), j;
	struct record* x = B[i];

	while (1)
	{
		j = 2 * i;

		if (j > R) break;

		if (j < R and (compare(*B[j + 1], *B[j]) == 1)) ++j;

		if (compare(*x, *B[j]) >= 0)  break;

		B[i] = B[j];
		i = j;
	}
	B[i] = x;
}

void HeapSort(struct record** B, int n)
{
	int R = n - 1;
	int L = (n - 1) / 2;
	while (L >= 0)
	{
		Heap(B, L, R);
		--L;
	}

	while (R > 0)
	{
		swap(B[0], B[R]); // <iostream>
		R--;
		Heap(B, 0, R);
	}
}

struct q {
	q* next;

	union {
		int w;
		unsigned char digit[sizeof(int)];
	};
	record* st;
};

struct Q {
	q* head;
	q* tail;
};

void printlist(q* h, int k)
{
	while (h != NULL)
	{
		cout << k + 1 << ")\t ";
		cout << h->st->author << "   ";
		cout << h->st->title << " ";
		cout << h->st->publisher << " ";
		cout << h->st->year << " ";
		cout << h->st->num_of_page << " ";
		printf("weight= ");
		cout << h->w << endl;
		h = h->next; k++;
	}
	int c;
	puts("press any digit('1', '2'...etc) and press ENTER");
	scanf("%d", &key);
	return;
}

void Search(record* a[], int n, q** tail)
{
	int L, R, m; char x[3];
	srand(time(NULL));
	//int g=rand()%4000;
	strncpy(x, a[rand() % 4000]->publisher, 3);
	printf("%c%c%c", x[0], x[1], x[2]);
	L = 0;
	R = n - 1;
	while (L < R)
	{
		m = (L + R) / 2;
		if (strncmp(a[m]->publisher, x, 3) < 0)
			L = m + 1;
		else R = m;
	}
	if (strncmp(a[R]->publisher, x, 3) == 0) {
		puts("\n\nFound notes: ");
		q* s;
		while (R < 4000 && strncmp(a[R]->publisher, x, 3) == 0)
		{
			s = new q;
			s->st = a[R];
			s->w = rand() % 100;
			(*tail)->next = s;
			*tail = s;
			R++;
		}
		(*tail)->next = NULL;
	}
	else puts("Notes weren't found");
}

void DigitalSort(q** head, q** tail)
{
	int d, i, j, k, l = 4;
	q* p;

	struct Q g[256];
	int KDI[l];
	for (i = 0; i < l; i++)
		KDI[i] = i;

	for (j = l - 1; j >= 0; j--)
	{
		for (i = 0; i < 256; i++) g[i].tail = (q*)&g[i].head;
		p = *head;
		k = KDI[j];
		while (p != NULL)
		{
			d = p->digit[k];
			g[d].tail->next = p;
			g[d].tail = p;
			p = p->next;
		}
		p = (q*)&(*head);
		for (i = 0; i < 256; i++)
		{
			if (g[i].tail != (q*)&g[i].head)
			{
				p->next = g[i].head;
				p = g[i].tail;
			}
		}
		p->next = NULL;
	}
}

q* reversing(q* root)
{
	q* new_root = NULL;
	while (root)
	{
		q* next = root->next;
		root->next = new_root;
		new_root = root;
		root = next;
	}
	return new_root;
}

struct Tree {
	record* st;
	Tree* left;
	Tree* right;
	Tree* equal;
};

void add_to_tree(record* D, Tree*& p)
{
	if (p == NULL)
	{
		p = (Tree*)malloc(sizeof(Tree));
		p->st = D;
		p->left = p->right = p->equal = NULL;
	}
	else if (D->num_of_page < p->st->num_of_page)
		add_to_tree(D, p->left);
	else if (D->num_of_page > p->st->num_of_page)
		add_to_tree(D, p->right);
	else if (D->num_of_page == p->st->num_of_page)
		add_to_tree(D, p->equal);
	else return;
}

void building_tree(q* h, Tree*& p)
{
	while (h != NULL)
	{
		add_to_tree(h->st, p);
		h = h->next;
	}
	puts("");
}

int num1 = 1;

void INfix_PrintTree(Tree* Root)
{
	if (Root == NULL)
		return;
	if (Root->left != NULL)
		INfix_PrintTree(Root->left);
	cout << num1 << ")\t ";
	cout << Root->st->author << "   ";
	cout << Root->st->title << " ";
	cout << Root->st->publisher << " ";
	cout << Root->st->year << " ";
	cout << Root->st->num_of_page << endl;
	num1++;
	if (Root->equal != NULL)
		INfix_PrintTree(Root->equal);
	if (Root->right != NULL)
		INfix_PrintTree(Root->right);
}

void find(Tree* p, int a)
{

	if (p != NULL) {
		if (a == p->st->num_of_page)
		{
			while (p != NULL) {
				cout << num1 << ")\t ";
				cout << p->st->author << "   ";
				cout << p->st->title << " ";
				cout << p->st->publisher << " ";
				cout << p->st->year << " ";
				cout << p->st->num_of_page << endl;
				num1++;
				p = p->equal;
			}
			puts("press any digit('1', '2'...etc) and press ENTER");
			scanf("%d", &key);
		}
		else if (a > p->st->num_of_page)
			find(p->right, a);
		else if (a < p->st->num_of_page)
			find(p->left, a);
	}
	else {
		puts("\nNote not found");
		puts("press any digit('1', '2'...etc) and press ENTER");
		scanf("%d", &key);
	}
}

struct sym { //��������� ��� �����������. ��� ����� ��������� ������� 
	sym* next;
	float P;	// ����������� �������
	unsigned char data;// ��� ������
	int num = 0;	//���������� ������� � �����	
};

struct Queue {
	sym* head;
	sym* tail;
};

struct s {//���� ��������� ��� ����������� . ���� ������������ ������ �� ������� sym 
	float P;
	float Preal; //������ ����������� ����� �� ��� � ������ float P �� ����� �������������� ����������� Preal 
	//             ��� ��� �� ������ �������, � ����������� ��������� � ����� ������ ���������� �����(L)  � �������� (H) ���-�� ���������.
	char data;
	int num;
	int L = 0;// ����� �������� �����
	char* C; // ������� ������������ �����.
};

void LoadToList(sym*& head, unsigned char ch, int& size)
{
	if (head == NULL) {
		head = new sym;
		head->data = ch;
		head->num++;
		size++;
		head->next = NULL;

	}
	else if (head->data == ch)
		head->num++;
	else LoadToList(head->next, ch, size);
}

void printinglist(sym* head, int size, int count, int a)
{
	while (head != NULL)
	{
		if (a == 1)
			head->P = (float)head->num / count;

		printf("\n%c\t%d\t%2.4f ", head->data, head->num, head->P);
		head = head->next;
	}
}

void StackToQueue(struct sym** head, struct sym** tail) {
	(*tail)->next = *head;
	*tail = *head;
	*head = (*head)->next;
	(*tail)->next = NULL;
}

void MergeS(sym** head_a, sym** head_b, sym** tail, int q, int r) {
	while (q != 0 && r != 0) {

		if ((*head_a)->P <= (*head_b)->P) {
			StackToQueue(head_a, tail);
			q--;
		}
		else {
			StackToQueue(head_b, tail);
			r--;
		}
	}
	while (q > 0) {
		StackToQueue(head_a, tail);
		q--;
	}
	while (r > 0) {
		StackToQueue(head_b, tail);
		r--;
	}
}

void Split(sym** head, sym** head_a, sym** head_b) {
	sym* k, * p;
	*head_a = *head;
	*head_b = (*head)->next;
	k = *head_a;
	p = *head_b;
	while (p != NULL) {
		k->next = p->next;
		k = p;
		p = p->next;
	}
}

void MergeSort(sym** head, sym** tail, int n) {
	int i, m, q, p = 1, r;
	sym* a = NULL, * b = NULL;
	Queue c[2];
	Split(head, &a, &b);
	while (p < n) {
		c[0].tail = (sym*)&c[0].head;
		c[1].tail = (sym*)&c[1].head;
		i = 0;
		m = n;
		while (m > 0) {
			if (m >= p) q = p;
			else q = m;
			m -= q;
			if (m >= p) r = p;
			else r = m;
			m -= r;
			MergeS(&a, &b, &c[i].tail, q, r);
			i = 1 - i;
		}
		a = c[0].head;
		b = c[1].head;
		p *= 2;
	}
	c[0].tail->next = NULL;
	*head = c[0].head;
}

sym* to_reverse(sym* head)
{
	sym* new_head = NULL;
	while (head)
	{
		sym* next = head->next;
		head->next = new_head;
		new_head = head;
		head = next;
	}
	return new_head;
}

void to_array(s charac[], sym* head1, int size)
{
	for (int i = 0; i < size; i++)
	{
		charac[i].data = head1->data;
		charac[i].num = head1->num;
		charac[i].P = charac[i].Preal = head1->P;
		charac[i].C = new char[size];
		head1 = head1->next;
	}
}

int Up(int n, float  q, s charac[])
{
	int j = 0;
	for (int i = n - 1; i > 0; i--)
	{
		if (charac[i - 1].P <= q)
			charac[i].P = charac[i - 1].P;
		else
		{
			j = i;
			break;
		}
	}
	charac[j].P = q;
	return j;
}

void Down(int n, int j, s charac[], int size)
{
	char* S = new char[size];
	strcpy(S, charac[j].C);
	int L = charac[j].L;
	for (int i = j; i <= n - 2; i++)
	{
		strcpy(charac[i].C, charac[i + 1].C);
		charac[i].L = charac[i + 1].L;
	}
	strcpy(charac[n - 1].C, S);
	strcpy(charac[n].C, S);
	charac[n - 1].C[L] = '0';
	charac[n].C[L] = '1';
	charac[n - 1].L = L + 1;
	charac[n].L = L + 1;
	delete S;
}

void coding_Haffman(s charac[], int n, int size)
{
	if (n == 1)
	{
		charac[0].C[0] = '0';
		charac[0].L = 1;
		charac[1].C[0] = '1';
		charac[1].L = 1;
	}
	else {
		float q = charac[n - 1].P + charac[n].P;
		int j = Up(n, q, charac);
		coding_Haffman(charac, n - 1, size);
		Down(n, j, charac, size);
	}
}

float totalP(s symbols[], float P, int size)
{
	int i = 0;
	while (i < size)
	{
		P += symbols[i].Preal;
		i++;
	}
	return P;
}

int readingfile(int& size, int& count, sym*& head1)
{
	FILE* p = fopen("testBase1.dat", "rb");
	unsigned char ch;
	if (p == NULL) {
		printf("Can't open file");
		return 0;
	}
	while (fread(&ch, sizeof(unsigned char), 1, p) != 0)
	{
		count++;
		LoadToList(head1, ch, size);
	}
	fclose(p);
	return 1;
}

void printingcodes(float L_av, float H, s charac[], int size, float Ptotal)
{
	printf("\n\n\n i  Char  P   L  Code\n");
	for (int i = 0; i < size; i++) {
		printf("%3d %c  %.2f  %2d  ", i + 1, charac[i].data, charac[i].Preal, charac[i].L);
		for (int j = 0; j < charac[i].L; j++)
			printf("%c", charac[i].C[j]);
		puts("");
	}
	for (int i = 0; i < size; i++) {
		H += -charac[i].Preal * log2f(charac[i].Preal);
		L_av += charac[i].Preal * charac[i].L;
	}
	printf("\n\nH: %.2f\nL_av: %.2f\nPtotal: %.2f\n", H, L_av, totalP(charac, Ptotal, size));
	puts("\n\npress any digit('1', '2'...etc) and press ENTER");
	scanf("%d", &key);
}

int main()
{
	SetConsoleCP(1251);

	const int n = 4000;
	struct record tt[n];
	struct record* B[n];
	q* head = NULL, * tail = (q*)&head;
	Tree* root = NULL;
	int temp = 0; int c;

	while (1)
	{
		cout << "1 - Scan BD " << endl;
		cout << "2 - Print BD " << endl;
		cout << "3 - Sort Array " << endl;
		cout << "4 - Print Array " << endl;
		cout << "5 - Search. pered poiskim nujno sdelatb 'Scan BD' i 'Sort Array'" << endl;
		cout << "6 - Show tree. pered derevom nujno sdelatb 'Search'" << endl;
		cout << "7 - Find record in tree. pered posikim v dereve nujno sdelatb 'Show tree' " << endl;
		cout << "8 - Haffman. korga 3apustitca haffman to kampukter mojet izdavatb ebanutiu zvuk. ETO NORMA NE NADO nYrATbC9I" << endl;
		cout << "0 - End " << endl;
		cin >> temp;
		switch (temp)
		{
		case 1:
			scan(tt, B, n);
			break;
		case 2:
			print_database(tt, n);
			break;
		case 3:
			HeapSort(B, n);
			break;
		case 4:
			print_arr(B, n);
			break;
		case 5:
			Search(B, n, &tail);
			printlist(head, 0);
			break;
		case 6:
			DigitalSort(&head, &tail);
			head = reversing(head);
			building_tree(head, root);
			INfix_PrintTree(root);
			puts("\npress any digit('1', '2'...etc) and press ENTER");
			scanf("%d", &key);
			break;
		case 7:
			num1 = 1;
			int page;
			puts("\nEnter wanted page number:");
			scanf("%d", &page);
			find(root, page);
			break;
		case 8:
		{
			int count = 0, size = 0; float H = 0, L_av = 0, Ptotal = 0;
			sym* head1 = NULL, * tail1 = (sym*)&head1;

			if (readingfile(size, count, head1) == 0)
				return 0;
			s charac[size];

			printinglist(head1, size, count, 1);
			MergeSort(&head1, &tail1, size);
			head1 = to_reverse(head1);
			to_array(charac, head1, size);
			coding_Haffman(charac, size - 1, size);
			printingcodes(L_av, H, charac, size, Ptotal);
			break;
		}

		case 0:
			//return 1;
			break;
		}
		system("cls");
	}
	return 1;
}
