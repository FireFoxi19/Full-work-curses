#include <iostream>
#include <time.h>
#include <stdlib.h>

using namespace std;

int main() {

	srand(time(NULL));
	int mas[10], tabl[9], mod, temp = 1, x = 0, kollizii[2] = { 0, 0 };
	cout << "Linear method = >" << endl << "Array = >" << endl;
	for (int i = 0; i < 10; i++)
	{
		mas[i] = rand() % 60 + 10;
		cout << mas[i] << " ";
	}

	cout << endl;
	for (int i = 0; i < 9; i++)
	{
		tabl[i] = 0;
	}

	for (int i = 0; i < 10; i++)
	{
		temp = 1;
		mod = mas[i] % 9;
		if (tabl[mod] == 0)
		{
			tabl[mod] = mas[i];
		}

		else
		{
			kollizii[0]++;
			x = mod + temp;
			while (tabl[x] != 0 && temp < 9)
			{
				kollizii[0]++;
				temp += 1;
				x = mod + temp;
				if (x >= 9)
				{
					x -= 9;
				}
			}

			if (temp >= 9)
			{
				cout << "Element = > " << mas[i] << " - overflow" << endl;
			}

			if (tabl[x] == 0)
			{
				tabl[x] = mas[i];
				x = 0;
				temp = 1;
			}
		}
	}

	for (int i = 0; i < 9; i++)
	{
		cout << "* " << i << " ";
	}

	cout << "*" << endl;
	for (int i = 0; i < 9; i++)
	{
		cout << "* " << tabl[i] << " ";
	}

	cout << "*" << endl;
	cout << endl;
	cout << "Quadratic method = >" << endl << "Array = >" << endl;
	for (int i = 0; i < 10; i++)
	{
		mas[i] = rand() % 60 + 10;
		cout << mas[i] << " ";
	}

	cout << endl;
	for (int i = 0; i < 9; i++)
	{
		tabl[i] = 0;
	}

	x = temp = 0;

	for (int i = 0; i < 10; i++)
	{
		temp = 1;
		mod = mas[i] % 9;
		if (tabl[mod] == 0)
		{
			tabl[mod] = mas[i];
		}
		else
		{
			kollizii[1]++;
			x = mod + temp;
			while (tabl[x] != 0 && temp < 9)
			{
				kollizii[1]++;
				temp += 2;
				x = mod + temp;
				if (x >= 9)
				{
					x -= 9;
				}
			}
			if (temp >= 9)
			{
				cout << "Element = > " << mas[i] << " - overflow" << endl;
			}

			if (tabl[x] == 0)
			{
				tabl[x] = mas[i];
				x = 0;
				temp = 1;
			}
		}
	}

	for (int i = 0; i < 9; i++)
	{
		cout << "* " << i << " ";
	}

	cout << "*" << endl;
	cout << "* " << tabl[0] << " ";
	for (int i = 1; i < 9; i++)
	{
		cout << "* " << tabl[i] << " ";
	}

	cout << "*" << endl;
	cout << endl << "Size of hash table = > 9" << endl;
	cout << "Count of symbols = > 10" << endl;
	cout << "Count collisions of linear tests = > " << kollizii[0] << endl;
	cout << "Count collisions of quadratic tests = > " << kollizii[1] << endl;
	return 0;
}