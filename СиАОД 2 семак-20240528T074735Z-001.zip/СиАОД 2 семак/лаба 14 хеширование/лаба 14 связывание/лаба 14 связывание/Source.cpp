#include <iostream>
#include <cmath>
#include <ctime>

using namespace std;

typedef struct tp 
{
	int number;
	struct tp* next;
} s;

void output(s* head)
{

	s* p = head->next;
	while (p != NULL) {

		cout << p->number << " ";
		p = p->next;
	}
	cout << endl;
}

int main()
{

	int A[12];
	int m = 6;
	int i;
	int conflicts[6], poisk = 0;
	int key, flag = 0, h, balance = 0;
	s* B[6];
	s* p, * q;
	cout << "Fill array (12 elements) = > ";
	for (i = 0; i < 12; i++)
	{
		A[i] = rand() % 50;
		cout << A[i] << endl;
	}

	for (i = 0; i < m; i++)
	{
		B[i] = new tp;
	}

	for (i = 0; i < m; i++)
	{
		B[i]->number = i;
		B[i]->next = NULL;
	}

	for (i = 0; i < m; i++)
	{
		conflicts[i] = -1;
	}

	for (i = 0; i < 12; i++)
	{
		balance = A[i] % m;
		p = new tp;
		q = B[balance];
		while (q->next != NULL)
		{
			q = q->next;
		}

		q->next = p;
		p->number = A[i];
		conflicts[balance]++;
		p->next = NULL;
	}

	cout << "Hash = >" << endl;
	for (i = 0; i < m; i++)
	{
		cout << i << "\t";
		output(B[i]);
	}

	for (i = 0; i < m; i++)
	{
		if (conflicts[i] > 0)
		{
			cout << "Collisions in " << i << " list = > " << conflicts[i] << endl;
		}
	}

	cout << endl;
	cout << "Enter the key = > ";
	cin >> key;
	h = key % m;
	cout << endl;
	p = new tp;
	q = B[h];
	q = q->next;
	while (q != NULL)
	{
		if (q->number == key)
		{
			if (!flag)
			{
				cout << "Element found in a string with number: " << h << endl;
			}
			poisk++;
			flag = 1;
		}
		q = q->next;
	}

	if (!flag)
	{
		cout << "Error, element not found";
	}
	if (poisk > 0)
	{
		cout << "Collisions in the search: " << poisk - 1;
	}
	return 0;
}