#include <cstdio>
#include <conio.h>
#include <cstdlib>
#include <clocale>
#include <iostream>
#include <ctime>

const int nMax = 501;

struct vertex {
    int data;
    int bal;
    vertex* left;
    vertex* right;
};

int arr[nMax];
int n;
bool rost;
bool small;
vertex* q = NULL;

int random(int x) {
    return rand() % x;
}

void MakeTree(vertex*& root, int D) {
    if (root == NULL) {
        root = new vertex;
        root->data = D;
        root->left = NULL;
        root->right = NULL;
    }
    else if (root->data < D) {
        MakeTree(root->right, D);
    }
    else if (root->data > D) {
        MakeTree(root->left, D);
    }
}

int Max(int l, int r) {
    if (l > r)
        return l;
    return r;
}

int Size(vertex* p) {
    if (p == NULL)
        return 0;
    return 1 + Size(p->left) + Size(p->right);
}

int Height(vertex* p) {
    if (p == NULL)
        return 0;
    return 1 + Max(Height(p->left), Height(p->right));
}

long LenSum(vertex* p, int l) {
    if (p == NULL)
        return 0;
    return l + LenSum(p->left, l + 1) + LenSum(p->right, l + 1);
}

float AverageHeight(vertex* p) {
    return LenSum(p, 1) * 1.0 / Size(p);
}

long Sum(vertex* p) {
    if (p == NULL)
        return 0;
    return p->data + Sum(p->left) + Sum(p->right);
}

int IsSearchTree(vertex* p) {
    if (p != NULL &&
        (
            (p->left != NULL) && ((p->data <= p->left->data) || !IsSearchTree(p->left)) ||
            (p->right != NULL) && ((p->data >= p->right->data) || !IsSearchTree(p->right))
            )
        )
        return 0;
    return 1;
}


int Search(vertex* p, int key) {
    while (p != NULL) {
        if (key < p->data)
            p = p->left;
        else if (key > p->data)
            p = p->right;
        else
            break;
    }
    if (p != NULL)
        return 1;
    return 0;
}


void LeftToRight(vertex* p) {
    if (p != NULL) {
        LeftToRight(p->left);
        std::cout << p->data << ' ';
        LeftToRight(p->right);
    }
}

void UpToDown(vertex* p) {
    if (p != NULL) {
        std::cout << p->data << ' ';
        UpToDown(p->left);
        UpToDown(p->right);
    }
}

void DownToUp(vertex* p) {
    if (p != NULL) {
        DownToUp(p->left);
        DownToUp(p->right);
        std::cout << p->data << ' ';
    }
}

void Delete(vertex*& root, int A) {
    vertex** p;
    vertex* q, * s, * r;
    p = &root;

    while (*p != NULL) {
        if ((*p)->data < A) {
            p = &((*p)->right);
        }
        else if ((*p)->data > A) {
            p = &((*p)->left);
        }
        else {
            break;
        }
    }

    if (*p != NULL) {
        q = *p;
        if (q->left == NULL) {
            *p = q->right;
        }
        else if (q->right == NULL) {
            *p = q->left;
        }
        else {
            r = q->left;
            s = q;
            if (r->right == NULL) {
                r->right = q->right;
                *p = r;
            }
            else {
                while (r->right != NULL) {
                    s = r;
                    r = r->right;
                }
                s->right = r->left;
                r->left = q->left;
                r->right = q->right;
                *p = r;
            }
        }
        delete (q);
    }
}

void LL(vertex*& p) {
    vertex* q = p->left;
    p->bal = 0;
    q->bal = 0;
    p->left = q->right;
    q->right = p;
    p = q;
}

void LR(vertex*& p) {
    vertex* q = p->left;
    vertex* r = q->right;
    if (r->bal < 0) {
        p->bal = 1;
    }
    else {
        p->bal = 0;
    }
    if (r->bal > 0) {
        q->bal = -1;
    }
    else {
        q->bal = 0;
    }
    r->bal = 0;
    q->right = r->left;
    p->left = r->right;
    r->left = q;
    r->right = p;
    p = r;
}

void RR(vertex*& p) {
    vertex* q = p->right;
    p->bal = 0;
    q->bal = 0;
    p->right = q->left;
    q->left = p;
    p = q;
}

void RL(vertex*& p) {
    vertex* q = p->right;
    vertex* r = q->left;
    if (r->bal > 0) {
        p->bal = -1;
    }
    else {
        p->bal = 0;
    }
    if (r->bal < 0) {
        q->bal = 1;
    }
    else {
        q->bal = 0;
    }
    r->bal = 0;
    p->right = r->left;
    q->left = r->right;
    r->left = p;
    r->right = q;
    p = r;
}

void makeAVL(int D, vertex*& p) {
    if (p == NULL) {
        p = new vertex;
        p->data = D;
        p->left = NULL;
        p->right = NULL;
        p->bal = 0;
        rost = true;
    }
    else {
        if (p->data > D) {
            makeAVL(D, p->left);
            if (rost) {
                if (p->bal > 0) {
                    p->bal = 0;
                    rost = false;
                }
                else {
                    if (p->bal == 0) {
                        p->bal = -1;
                        rost = true;
                    }
                    else {
                        if (p->left->bal < 0) {
                            LL(p);
                            rost = false;
                        }
                        else {
                            LR(p);
                            rost = false;
                        }
                    }
                }
            }
        }
        else {
            if (p->data < D) {
                makeAVL(D, p->right);
                if (rost) {
                    if (p->bal < 0) {
                        p->bal = 0;
                        rost = false;
                    }
                    else if (p->bal == 0) {
                        p->bal = 1;
                        rost = true;
                    }
                    else {
                        if (p->right->bal > 0) {
                            RR(p);
                            rost = false;
                        }
                        else {
                            RL(p);
                            rost = false;
                        }
                    }

                }
            }
            else {
                std::cout << "������� � ������ ��� ����" << std::endl;
            }
        }
    }
}

void LL1(vertex*& p) {
    vertex* q;
    q = p->left;
    if (q->bal == 0)
    {
        q->bal = 1;
        p->bal = -1;
        small = false;
    }
    else
    {
        q->bal = 0;
        p->bal = 0;
    }
    p->left = q->right;
    q->right = p;
    p = q;
}

void RR1(vertex*& p) {
    vertex* q;
    q = p->right;
    if (q->bal == 0)
    {
        q->bal = -1;
        p->bal = 1;
        small = false;
    }
    else
    {
        q->bal = 0;
        p->bal = 0;
    }
    p->right = q->left;
    q->left = p;
    p = q;
}

void BL(vertex*& p) {
    if (p->bal == -1)
    {
        p->bal = 0;
    }
    else if (p->bal == 0)
    {
        p->bal = 1;
        small = false;
    }
    else if (p->bal == 1)
    {
        if (p->right->bal >= 0)
        {
            RR1(p);
        }
        else
        {
            RL(p);
        }
    }
}

void BR(vertex*& p) {
    if (p->bal == 1)
    {
        p->bal = 0;
    }
    else if (p->bal == 0)
    {
        p->bal = -1;
        small = 0;
    }
    else if (p->bal == -1)
    {
        if (p->left->bal <= 0)
        {
            LL1(p);
        }
        else
        {
            LR(p);
        }
    }
}

void Del(vertex*& r) {
    if (r->right != NULL)
    {
        Del(r->right);
        if (small == true)
        {
            BR(r);
        }
    }
    else
    {
        q->data = r->data;
        q = r;
        r = r->left;
        small = true;
    }
}

void DelAVL(int x, vertex*& p) {
    if (p == NULL) {
        std::cout << "����� ������ � ������ ���" << std::endl;
    }
    else if (p->data > x) {
        DelAVL(x, p->left);
        if (small) {
            BL(p);
        }
    }
    else if (p->data < x) {
        DelAVL(x, p->right);
        if (small) {
            BR(p);
        }
    }
    else {
        q = p;
        if (q->right == NULL) {
            p = q->left;
            small = true;
        }
        else if (q->left == NULL) {
            p = q->right;
            small = true;
        }
        else {
            Del(q->left);
            if (small) {
                BL(p);
            }
        }
        free(q);
    }
}


int main() {
    using namespace std;
    setlocale(LC_ALL, "Russian");
    srand(time(NULL));
    int Array[10];
    for (int i = 0; i < 10; i++) {
        Array[i] = rand() % 100;
    }
    cout << endl;
    vertex* root = NULL;
    for (int i = 0; i < 10; i++) {
        makeAVL(Array[i], root);
    }
    LeftToRight(root);
    cout << endl;
    for (int i = 0; i < 10; i++) {
        cout << "�������� " << Array[i] << endl;
        DelAVL(Array[i], root);
        cout << "����� ����� �������: ";
        LeftToRight(root);
        cout << endl << "����������� ����� " << Sum(root) << endl;
        cout << "������ ������ " << Height(root) << endl;
        cout << "������� ������ ������ " << AverageHeight(root) << endl;
        cout << endl;
    }

}