#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <Windows.h>

using namespace std;

struct record
{
	char author[12];
	char title[32];
	char publisher[16];
	short int year;
	short int num_of_page;

};
void scan(record *tt, FILE* fp, int n)
{
	fopen_s(&fp, "testBase1.dat", "rb");
	fread((record*)tt, sizeof(record), 4000, fp);
	fclose(fp);
}

int strcomp(const string& str1, const string& str2, int len = 1000000) {
	for (int i = 0; i < len; ++i) {
		if (str1[i] == '\0' and str2[i] == '\0') {
			return 0;
		}
		else if (str1[i] == ' ' and str2[i] != ' ') {
			return -1;
		}
		else if (str1[i] != ' ' and str2[i] == ' ') {
			return 1;
		}
		else if (str1[i] < str2[i]) {
			return -1;
		}
		else if (str1[i] > str2[i]) {
			return 1;
		}
	}
	return 0;
}

int compare(const record& record1, const record& record2) {
	if (record1.publisher > record2.publisher) {
		return 1;
	}
	else if (record1.publisher < record2.publisher) {
		return -1;
	}
	else {
		return strcomp(record1.author, record2.author);
	}
}


void Heap(struct record** B, int L, int R)
{
	int i, j;
	struct record* temp;
	temp = B[L];
	i = L;
	while (1)
	{
		j = 2 * i;
		if (j > R)
			break;
		if (j < R)
		{
			if (compare(*B[j+1], *B[j]) != -1)
				++j;
			if (compare(*temp, *B[j]) != -1)
				break;
		}
		if (temp->author <= B[j]->author)
			break;
		B[i] = B[j];
		i = j;
	}
	B[i] = temp;
}

void HeapSort(struct record** B, int n)
{
	int i, j, R = n - 1;
	struct record* temp;
	int L = (n-1) / 2;
	while (L >= 0)
	{
		Heap(B, L, R);
		--L;
	}
	while (R > 0)
	{
		temp = B[0];
		B[0] = B[R];
		B[R] = temp;
		R--;
		Heap(B, 0, R);
	}
}
int main()
{
	SetConsoleCP(1251);

	const int n = 4000;
	FILE* fp;
	fp = NULL;
	struct record tt[n];
	struct record *B[n];
	
	scan(tt, fp, n);

	for (int i = 0; i < n; i++) // ������ � ������ ����������
	{
		B[i] = &tt[i];
	}
	
	HeapSort(B, n);
	int tmp;
	for (int i = 0; i < n; ++i)
	{
		cout << tt[i].author << setw(10)<<"|" << tt[i].title << setw(8) << tt[i].publisher << setw(6) << tt[i].year << setw(10) << tt[i].num_of_page << endl;
		if (i % 20 == 0 && i != 0)
		{
			cin >> tmp;
			if (tmp == 1) system("CLS");
			if (tmp == 0) break;
		}
	}
	fclose(fp);
	return 1;
}