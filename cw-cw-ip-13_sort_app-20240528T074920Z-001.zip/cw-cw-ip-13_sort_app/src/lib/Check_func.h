#pragma once

void check_size(int &size, char *argv);
bool check_value(float buffer);
int check_type(int s_i, int choise, char *argv);
int check_border(int size, int choise, char *argv[]);