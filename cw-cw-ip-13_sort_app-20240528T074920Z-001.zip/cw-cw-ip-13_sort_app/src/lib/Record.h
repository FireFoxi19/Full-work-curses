#pragma once
#include <vector>

void record_array(std::vector<float> &array, char *argv);
void output_data(std::vector<float> &array, char **argv, int argc);