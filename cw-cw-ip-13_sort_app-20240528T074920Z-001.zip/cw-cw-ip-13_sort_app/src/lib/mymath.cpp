#include <cmath>
#include <iostream>

double log_2(int b, int a) { return ((log(b) / log(a)) - 1); }