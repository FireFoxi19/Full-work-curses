#pragma once
double log_2(int b, int a);